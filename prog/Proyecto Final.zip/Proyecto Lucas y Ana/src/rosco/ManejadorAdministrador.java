package rosco;

public class ManejadorAdministrador {

}
