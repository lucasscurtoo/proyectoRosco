package rosco;

public class ManejadorPartidas {


}
