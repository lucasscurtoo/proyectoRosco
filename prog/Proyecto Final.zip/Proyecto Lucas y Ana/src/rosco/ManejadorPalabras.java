package rosco;

public class ManejadorPalabras {
	

}
