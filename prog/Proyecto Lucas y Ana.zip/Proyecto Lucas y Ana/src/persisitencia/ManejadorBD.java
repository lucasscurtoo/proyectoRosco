package persisitencia;

import rosco.Palabra;
import rosco.Usuario;

public class ManejadorBD {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	public boolean validarAdmin(int ciA, int pinA) {
		return false;
	}
	public void addAdministrador(Usuario admin) {	
		
	}
	public void deleteAdministrador(int ci) {
	
	}
	public void addPalabra(Palabra palabra) {
		
	}
	public void deletePalabra(int ciA, int pinA) {
		
	}
	
	public Palabra obtenerPalabra(char c) {
		// TODO Auto-generated method stub
		return null;
	}

}
