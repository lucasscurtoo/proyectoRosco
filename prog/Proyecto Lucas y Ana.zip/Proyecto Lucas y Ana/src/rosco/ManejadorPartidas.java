package rosco;

import persisitencia.ManejadorBD;

public class ManejadorPartidas {

	public void nuevaPartida(String nickName, int pin, String categoria) {
		ManejadorBD manejbd = new ManejadorBD();
		
	}

}
