package rosco;

public class Administrador extends Usuario {

	public Administrador(int ci, String nombre, String apellido, String mail, int pin) {
		super(ci, nombre, apellido, mail, pin);
		
	}

	}

